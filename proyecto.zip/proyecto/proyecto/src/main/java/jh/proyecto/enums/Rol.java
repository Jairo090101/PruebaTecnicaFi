package jh.proyecto.enums;

public enum Rol {
ADMIN, USER
}
